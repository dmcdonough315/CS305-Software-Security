//Dakota McDonough
//SNHU: CS305 Project 2

package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
public class SslServerApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
		//System.out.println("running public class!!!!!!");
	}
}

//Adding a hash function
@RestController
class ServerController{
	 public static String calculateHash(String name) throws NoSuchAlgorithmException 
	    {  
		 //Starting messageDigest SHA-256
	        MessageDigest md = MessageDigest.getInstance("SHA-256"); 

	        byte[] hash =  md.digest(name.getBytes(StandardCharsets.UTF_8));
	        
	        //Using this function to compensate for values that may lie outside the accepted range
	        //Source: https://www.geeksforgeeks.org/biginteger-class-in-java/
	        BigInteger number = new BigInteger(1, hash);
	        

	        //General formatting explanation: https://gist.github.com/dln/3175167
	        StringBuilder hexString = new StringBuilder(number.toString(16));  
	        for (byte b : hash) {
	        	hexString.append(String.format("%02x", b));
	        }  
	        return hexString.toString();  
	     
	    } 
	 
	@RequestMapping("/hash")
	@ResponseBody
	public String myHash() throws NoSuchAlgorithmException{
		

		
	String info = "Dakota McDonough";
	String hash = calculateHash(info);
	String printout = " Name of Cipher Algorithm Used : SHA-256.  CheckSum : ";
	String pdata = "<p>data: ";

	return pdata + info + printout + hash;

	}

	}

